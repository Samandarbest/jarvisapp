package com.uzmaxboy.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.uzmaxboy.jarvis.databinding.ActivityMainBinding
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var api: ApiClient
    private lateinit var adapter: ChatAdapter
    private var tts: TextToSpeech? = null

    private var pendingContactAction: String? = null // "call" yoki "sms"

    private val voiceLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val results = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = results?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                binding.editMessage.setText(spoken)
                sendMessage(spoken)
            }
        }
    }

    private val contactPickerLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val contactUri: Uri? = result.data?.data
            contactUri?.let { handlePickedContact(it) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        api = ApiClient(this)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("uz")
            }
        }

        adapter = ChatAdapter(mutableListOf()) { msg, approve -> onConfirmAction(msg, approve) }
        binding.recyclerChat.layoutManager = LinearLayoutManager(this)
        binding.recyclerChat.adapter = adapter

        binding.btnSend.setOnClickListener {
            val text = binding.editMessage.text.toString().trim()
            if (text.isNotEmpty()) {
                sendMessage(text)
                binding.editMessage.setText("")
            }
        }

        binding.btnMic.setOnClickListener { startVoiceInput() }

        if (!api.isConfigured()) {
            startActivity(Intent(this, SettingsActivity::class.java))
        } else {
            loadHistory()
        }

        scheduleReminderWorker()
    }

    private fun scheduleReminderWorker() {
        val request = androidx.work.PeriodicWorkRequestBuilder<ReminderWorker>(15, java.util.concurrent.TimeUnit.MINUTES).build()
        androidx.work.WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "jarvis_reminder_check",
            androidx.work.ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.action_call -> pickContactFor("call")
            R.id.action_sms -> pickContactFor("sms")
        }
        return true
    }

    /* ===================== CHAT ===================== */

    private fun loadHistory() {
        api.fetchHistory(50, object : ApiClient.Callback {
            override fun onSuccess(json: JSONObject) {
                val arr = json.optJSONArray("messages") ?: return
                val list = mutableListOf<ChatMessage>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(ChatMessage(o.optString("role"), o.optString("content")))
                }
                runOnUiThread {
                    adapter.setAll(list)
                    binding.recyclerChat.scrollToPosition(adapter.itemCount - 1)
                }
            }
            override fun onError(message: String) { /* tarixni yuklab bo'lmadi — jim o'tamiz */ }
        })
    }

    private fun sendMessage(text: String) {
        adapter.addMessage(ChatMessage("user", text))
        binding.recyclerChat.scrollToPosition(adapter.itemCount - 1)

        api.sendChat(text, object : ApiClient.Callback {
            override fun onSuccess(json: JSONObject) {
                val reply = json.optString("reply", "...")
                val pendingId = json.optString("pending_action", null)
                val pendingDesc = json.optString("pending_description", null)
                runOnUiThread {
                    adapter.addMessage(ChatMessage("assistant", reply, pendingId.takeIf { !it.isNullOrBlank() }, pendingDesc))
                    binding.recyclerChat.scrollToPosition(adapter.itemCount - 1)
                    speak(reply)
                }
            }
            override fun onError(message: String) {
                runOnUiThread {
                    adapter.addMessage(ChatMessage("assistant", "⚠️ Xatolik: $message"))
                    binding.recyclerChat.scrollToPosition(adapter.itemCount - 1)
                }
            }
        })
    }

    private fun onConfirmAction(msg: ChatMessage, approve: Boolean) {
        val pid = msg.pendingId ?: return
        api.confirmAction(pid, approve, object : ApiClient.Callback {
            override fun onSuccess(json: JSONObject) {
                runOnUiThread {
                    val resultText = if (approve) "✅ Bajarildi." else "❌ Bekor qilindi."
                    adapter.addMessage(ChatMessage("assistant", resultText))
                    binding.recyclerChat.scrollToPosition(adapter.itemCount - 1)
                }
            }
            override fun onError(message: String) {
                runOnUiThread { adapter.addMessage(ChatMessage("assistant", "⚠️ Xatolik: $message")) }
            }
        })
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    /* ===================== OVOZLI KIRISH ===================== */

    private fun startVoiceInput() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
        }
        voiceLauncher.launch(intent)
    }

    /* ===================== QO'NG'IROQ / SMS TAYYORLASH ===================== */
    // Eslatma: bu yerda faqat dialer/SMS ilovasini ochamiz — yuborish/qo'ng'iroq qilish
    // tugmasini foydalanuvchining o'zi bosishi shart (external_actions_require_user_control).

    private fun pickContactFor(action: String) {
        pendingContactAction = action
        val intent = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
        contactPickerLauncher.launch(intent)
    }

    private fun handlePickedContact(contactUri: Uri) {
        val cursor = contentResolver.query(contactUri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val number = if (numberIndex >= 0) it.getString(numberIndex) else null
                if (number != null) {
                    when (pendingContactAction) {
                        "call" -> startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
                        "sms" -> startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")))
                    }
                }
            }
        }
        pendingContactAction = null
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
