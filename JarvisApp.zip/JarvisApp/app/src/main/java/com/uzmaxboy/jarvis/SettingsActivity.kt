package com.uzmaxboy.jarvis

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.uzmaxboy.jarvis.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var api: ApiClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        api = ApiClient(this)

        binding.editServerUrl.setText(api.serverUrl())
        binding.editApiToken.setText(api.apiToken())
        binding.switchWakeWord.isChecked = api.wakeWordEnabled()

        binding.btnSaveSettings.setOnClickListener {
            api.saveSettings(
                binding.editServerUrl.text.toString().trim(),
                binding.editApiToken.text.toString().trim()
            )
            val wantsWakeWord = binding.switchWakeWord.isChecked
            api.setWakeWordEnabled(wantsWakeWord)

            val serviceIntent = Intent(this, WakeWordService::class.java)
            if (wantsWakeWord) {
                serviceIntent.action = WakeWordService.ACTION_START
                ContextCompat.startForegroundService(this, serviceIntent)
            } else {
                serviceIntent.action = WakeWordService.ACTION_STOP
                startService(serviceIntent)
            }
            finish()
        }
    }
}
