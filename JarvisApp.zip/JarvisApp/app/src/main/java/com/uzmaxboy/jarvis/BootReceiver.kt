package com.uzmaxboy.jarvis

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val api = ApiClient(context)
            if (api.isConfigured() && api.wakeWordEnabled()) {
                val serviceIntent = Intent(context, WakeWordService::class.java).setAction(WakeWordService.ACTION_START)
                ContextCompat.startForegroundService(context, serviceIntent)
            }
        }
    }
}
