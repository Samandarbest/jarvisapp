package com.uzmaxboy.jarvis

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.recyclerview.widget.RecyclerView
import com.uzmaxboy.jarvis.databinding.ItemMessageBinding

class ChatAdapter(
    private val items: MutableList<ChatMessage>,
    private val onConfirm: (ChatMessage, Boolean) -> Unit
) : RecyclerView.Adapter<ChatAdapter.VH>() {

    inner class VH(val binding: ItemMessageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemMessageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.textBubble.text = item.text

        val params = holder.binding.textBubble.layoutParams as LinearLayout.LayoutParams
        if (item.role == "user") {
            holder.binding.textBubble.setBackgroundResource(R.drawable.bg_bubble_user)
            holder.itemView.layoutDirection = View.LAYOUT_DIRECTION_RTL
            holder.binding.textBubble.layoutDirection = View.LAYOUT_DIRECTION_LTR
        } else {
            holder.binding.textBubble.setBackgroundResource(R.drawable.bg_bubble_assistant)
            holder.itemView.layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        if (item.pendingId != null) {
            holder.binding.confirmRow.visibility = View.VISIBLE
            holder.binding.btnConfirmYes.setOnClickListener { onConfirm(item, true) }
            holder.binding.btnConfirmNo.setOnClickListener { onConfirm(item, false) }
        } else {
            holder.binding.confirmRow.visibility = View.GONE
        }
    }

    override fun getItemCount() = items.size

    fun addMessage(msg: ChatMessage) {
        items.add(msg)
        notifyItemInserted(items.size - 1)
    }

    fun setAll(newItems: List<ChatMessage>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}
