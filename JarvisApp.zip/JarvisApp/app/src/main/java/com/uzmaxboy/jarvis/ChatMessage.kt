package com.uzmaxboy.jarvis

data class ChatMessage(
    val role: String,              // "user" yoki "assistant"
    val text: String,
    var pendingId: String? = null,
    var pendingDescription: String? = null
)
