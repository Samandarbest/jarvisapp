package com.uzmaxboy.jarvis

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.util.Locale

/**
 * "Jarvis" so'zini Picovoice'siz, Android'ning o'z nutq tanish tizimi (SpeechRecognizer)
 * orqali doimiy tsiklda tinglaydi. Hech qanday tashqi kalit/hisob talab qilmaydi.
 *
 * Ishlash tamoyili: recognizer navbat bilan qisqa tinglash seanslarini boshlaydi;
 * har bir seansning "partial" (oraliq) natijalarida "jarvis" so'zi qidiriladi.
 * Topilsa — undan keyingi matn buyruq sifatida yuboriladi (agar bo'lsa),
 * aks holda "Labbay" deb javob berib, keyingi gapni buyruq sifatida kutadi.
 */
class WakeWordService : Service() {

    companion object {
        const val CHANNEL_ID = "jarvis_wakeword"
        const val NOTIF_ID = 42
        const val ACTION_START = "START"
        const val ACTION_STOP = "STOP"
        @Volatile var isRunning = false

        private val WAKE_VARIANTS = listOf("jarvis", "jarves", "javis", "jorvis", "джарвис", "жарвис")
    }

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var api: ApiClient
    private val mainHandler = Handler(Looper.getMainLooper())
    private var awaitingCommand = false
    private var stopRequested = false

    override fun onCreate() {
        super.onCreate()
        api = ApiClient(this)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("uz")
        }
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopListening()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!isRunning) {
            stopRequested = false
            startForeground(NOTIF_ID, buildNotification("Tinglayapman... \"Jarvis\" deng"))
            isRunning = true
            startListeningCycle()
        }
        return START_STICKY
    }

    /** Doimiy tsikl: bitta tinglash seansi tugasa, darhol yangisini boshlaydi. */
    private fun startListeningCycle() {
        if (stopRequested) return
        recognizer?.destroy()

        val r = SpeechRecognizer.createSpeechRecognizer(applicationContext)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
                val text = matches.firstOrNull()?.lowercase(Locale.getDefault()) ?: return
                if (!awaitingCommand) {
                    val wake = WAKE_VARIANTS.firstOrNull { text.contains(it) } ?: return
                    val afterWake = text.substringAfter(wake, "").trim()
                    r.stopListening()
                    if (afterWake.length > 2) {
                        handleCommand(afterWake)
                    } else {
                        speakThenListenForCommand()
                    }
                }
            }

            override fun onResults(results: Bundle?) {
                if (awaitingCommand) {
                    awaitingCommand = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.firstOrNull()
                    if (!spoken.isNullOrBlank()) {
                        handleCommand(spoken)
                    } else {
                        restartSoon()
                    }
                } else {
                    restartSoon()
                }
            }

            override fun onError(error: Int) {
                awaitingCommand = false
                restartSoon()
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200)
        }
        try {
            r.startListening(intent)
        } catch (_: Exception) {
            restartSoon()
        }
    }

    private fun restartSoon() {
        if (stopRequested) return
        mainHandler.postDelayed({ startListeningCycle() }, 400)
    }

    private fun speakThenListenForCommand() {
        updateNotification("🎙 Eshityapman...")
        awaitingCommand = true
        tts?.speak("Labbay", TextToSpeech.QUEUE_FLUSH, null, null)
        mainHandler.postDelayed({ startListeningCycle() }, 900)
    }

    private fun handleCommand(text: String) {
        awaitingCommand = false
        updateNotification("⏳ Bajarilmoqda: \"$text\"")
        api.sendChat(text, object : ApiClient.Callback {
            override fun onSuccess(json: JSONObject) {
                val reply = json.optString("reply", "Tayyor.")
                tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, null)
                updateNotification("✅ $reply")
                restartSoon()
            }
            override fun onError(message: String) {
                tts?.speak("Xatolik yuz berdi", TextToSpeech.QUEUE_FLUSH, null, null)
                updateNotification("⚠️ $message")
                restartSoon()
            }
        })
    }

    private fun stopListening() {
        stopRequested = true
        mainHandler.removeCallbacksAndMessages(null)
        try { recognizer?.stopListening() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        isRunning = false
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "JARVIS wake-word", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): android.app.Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS")
            .setContentText(text)
            .setContentIntent(openIntent)
            .addAction(0, "To'xtatish", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        stopListening()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
