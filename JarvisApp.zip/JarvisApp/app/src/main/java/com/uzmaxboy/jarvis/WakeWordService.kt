package com.uzmaxboy.jarvis

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineActivationException
import ai.picovoice.porcupine.PorcupineException
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.util.Locale

class WakeWordService : Service() {

    companion object {
        const val CHANNEL_ID = "jarvis_wakeword"
        const val NOTIF_ID = 42
        const val ACTION_START = "START"
        const val ACTION_STOP = "STOP"
        @Volatile var isRunning = false
    }

    private var porcupineManager: PorcupineManager? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var api: ApiClient

    override fun onCreate() {
        super.onCreate()
        api = ApiClient(this)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("uz")
        }
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopListening()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> startListening()
        }
        return START_STICKY
    }

    private fun startListening() {
        if (isRunning) return
        val accessKey = api.picovoiceKey()
        if (accessKey.isBlank()) {
            updateNotification("⚠️ Picovoice AccessKey kiritilmagan (Sozlamalar'da to'ldiring)")
            stopSelf()
            return
        }

        startForeground(NOTIF_ID, buildNotification("Tinglayapman... \"Jarvis\" deng"))

        try {
            porcupineManager = PorcupineManager.Builder()
                .setAccessKey(accessKey)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.6f)
                .build(applicationContext, object : PorcupineManagerCallback {
                    override fun invoke(keywordIndex: Int) {
                        onWakeWordDetected()
                    }
                })
            porcupineManager?.start()
            isRunning = true
        } catch (e: PorcupineActivationException) {
            updateNotification("⚠️ Picovoice AccessKey noto'g'ri yoki faollashtirilmagan")
            stopSelf()
        } catch (e: PorcupineException) {
            updateNotification("⚠️ Wake-word xatoligi: ${e.message}")
            stopSelf()
        }
    }

    private fun onWakeWordDetected() {
        // Uyg'otuvchi so'z eshitildi — Porcupine'ni to'xtatib, buyruqni tinglaymiz
        try { porcupineManager?.stop() } catch (_: Exception) {}
        updateNotification("🎙 Eshityapman...")
        tts?.speak("Labbay", TextToSpeech.QUEUE_FLUSH, null, null)

        val recognizer = SpeechRecognizer.createSpeechRecognizer(applicationContext)
        speechRecognizer = recognizer
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: android.os.Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = matches?.firstOrNull()
                recognizer.destroy()
                if (!spoken.isNullOrBlank()) {
                    handleCommand(spoken)
                } else {
                    resumeWakeWordListening()
                }
            }
            override fun onError(error: Int) {
                recognizer.destroy()
                resumeWakeWordListening()
            }
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    private fun handleCommand(text: String) {
        updateNotification("⏳ Bajarilmoqda: \"$text\"")
        api.sendChat(text, object : ApiClient.Callback {
            override fun onSuccess(json: JSONObject) {
                val reply = json.optString("reply", "Tayyor.")
                tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, null)
                updateNotification("✅ $reply")
                resumeWakeWordListening()
            }
            override fun onError(message: String) {
                tts?.speak("Xatolik yuz berdi", TextToSpeech.QUEUE_FLUSH, null, null)
                updateNotification("⚠️ $message")
                resumeWakeWordListening()
            }
        })
    }

    private fun resumeWakeWordListening() {
        try {
            porcupineManager?.start()
            updateNotification("Tinglayapman... \"Jarvis\" deng")
        } catch (_: Exception) {
        }
    }

    private fun stopListening() {
        try { porcupineManager?.stop() } catch (_: Exception) {}
        try { porcupineManager?.delete() } catch (_: Exception) {}
        speechRecognizer?.destroy()
        isRunning = false
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "JARVIS wake-word", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): android.app.Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS")
            .setContentText(text)
            .setContentIntent(openIntent)
            .addAction(0, "To'xtatish", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        stopListening()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
