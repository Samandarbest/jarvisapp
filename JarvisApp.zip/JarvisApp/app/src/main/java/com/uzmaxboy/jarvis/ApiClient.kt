package com.uzmaxboy.jarvis

import android.content.Context
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiClient(context: Context) {

    private val prefs = context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json; charset=utf-8".toMediaType()

    fun serverUrl(): String = prefs.getString("server_url", "") ?: ""
    fun apiToken(): String = prefs.getString("api_token", "") ?: ""
    fun picovoiceKey(): String = prefs.getString("picovoice_key", "") ?: ""

    fun wakeWordEnabled(): Boolean = prefs.getBoolean("wake_word_enabled", false)
    fun setWakeWordEnabled(enabled: Boolean) { prefs.edit().putBoolean("wake_word_enabled", enabled).apply() }

    fun saveSettings(url: String, token: String, picovoiceKey: String) {
        prefs.edit()
            .putString("server_url", url)
            .putString("api_token", token)
            .putString("picovoice_key", picovoiceKey)
            .apply()
    }

    fun isConfigured(): Boolean = serverUrl().isNotBlank() && apiToken().isNotBlank()

    interface Callback {
        fun onSuccess(json: JSONObject)
        fun onError(message: String)
    }

    private fun post(body: JSONObject, cb: Callback) {
        if (!isConfigured()) {
            cb.onError("Avval Sozlamalar'da server manzili va tokenni kiriting.")
            return
        }
        val req = Request.Builder()
            .url(serverUrl())
            .addHeader("Authorization", "Bearer ${apiToken()}")
            .post(RequestBody.create(JSON, body.toString()))
            .build()

        client.newCall(req).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: Call, e: IOException) {
                cb.onError("Tarmoq xatoligi: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val bodyStr = response.body?.string() ?: "{}"
                try {
                    val json = JSONObject(bodyStr)
                    if (json.has("error")) {
                        cb.onError(json.getString("error"))
                    } else {
                        cb.onSuccess(json)
                    }
                } catch (e: Exception) {
                    cb.onError("Javobni o'qib bo'lmadi: ${e.message}")
                }
            }
        })
    }

    fun sendChat(message: String, cb: Callback) {
        val body = JSONObject().put("action", "chat").put("message", message)
        post(body, cb)
    }

    fun confirmAction(pendingId: String, approve: Boolean, cb: Callback) {
        val body = JSONObject().put("action", "confirm").put("pending_id", pendingId).put("approve", approve)
        post(body, cb)
    }

    fun fetchHistory(limit: Int, cb: Callback) {
        val body = JSONObject().put("action", "history").put("limit", limit)
        post(body, cb)
    }

    fun fetchReminders(cb: Callback) {
        post(JSONObject().put("action", "reminders"), cb)
    }
}
