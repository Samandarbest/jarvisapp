package com.uzmaxboy.jarvis

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Har 15 daqiqada backend'dagi jarvis_reminders jadvalini tekshiradi
 * (Telegram cron allaqachon o'z vaqtida yuboradi — bu faqat Android tomonda
 * push-bildirishnoma bo'lmagani uchun qo'shimcha zaxira mexanizmi).
 */
class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        val api = ApiClient(applicationContext)
        if (!api.isConfigured()) return Result.success()

        val latch = CountDownLatch(1)
        api.fetchReminders(object : ApiClient.Callback {
            override fun onSuccess(json: JSONObject) {
                val arr = json.optJSONArray("reminders")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val r = arr.getJSONObject(i)
                        if (r.optInt("is_sent") == 0) {
                            notify(r.optString("text"))
                        }
                    }
                }
                latch.countDown()
            }
            override fun onError(message: String) { latch.countDown() }
        })
        latch.await(20, TimeUnit.SECONDS)
        return Result.success()
    }

    private fun notify(text: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "jarvis_reminders"
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "JARVIS eslatmalari", NotificationManager.IMPORTANCE_HIGH)
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("⏰ JARVIS eslatmasi")
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        manager.notify(text.hashCode(), notification)
    }
}
